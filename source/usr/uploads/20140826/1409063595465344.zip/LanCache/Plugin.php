<?php
/**
 * Memcache Auto FLush
 * 
 * @package LanCache
 * @author Lan Tian
 * @version 1.0.0
 * @link http://lantian.eu.org
 */
class LanCache_Plugin implements Typecho_Plugin_Interface
{ 
    private static $pluginName = 'LanCache';
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
	Typecho_Plugin::factory('Widget_Feedback')->finishComment = array(self::$pluginName . '_Plugin', 'delCache');
	Typecho_Plugin::factory('Widget_Contents_Page_Edit')->write = array(self::$pluginName . '_Plugin', 'delCache');         
	Typecho_Plugin::factory('Widget_Contents_Post_Edit')->write = array(self::$pluginName . '_Plugin', 'delCache');
        Helper::addPanel(1, 'LanCache/panel.php', 'LanCache', 'Flush Cache',   'administrator');
        return 0;
    }
    
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){
        Helper::removePanel(1, 'LanCache/panel.php');
    }

    public static function delCache(){
                $mc = memcache_pconnect('127.0.0.1');
                memcache_flush($mc);
    }
    
    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {}

    public static function personalConfig(\Typecho_Widget_Helper_Form $form) {
        
    }

}
