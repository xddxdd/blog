<?php
include 'common.php';
include 'header.php';
include 'menu.php';
$mc = memcache_pconnect('127.0.0.1');
memcache_flush($mc);
?>
<div class="main">
    <div class="body container">
        <?php include 'page-title.php'; ?>
        <div class="container typecho-page-main" role="form">Flushed!</div>
    </div>
</div>
<?php
include 'copyright.php';
include 'common-js.php';
include 'footer.php';
include 'table-js.php';
?>
