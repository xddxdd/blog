百度贴吧云签到
==========

通过 BAE / SAE / CronTab 的计划任务实现百度贴吧自动签到。

![screenshot](http://ww1.sinaimg.cn/large/9b110883gw1e7r981cb6zj21060g40ud.jpg "screenshot")  

安装教程：
http://www.ikk.me/archives/default/bae_sign_installation_guide.html

更多信息：
http://www.ikk.me/archives/software/bae_tieba_sign.html

代码基本是原创的，基于 _短角 同学的签到函数重写了其他代码。
