<?php
if(!defined('IN_KKFRAME')) exit('Access Denied');
saveSetting('version', '1.13.8.21');
showmessage('成功更新到 1.13.8.21！', './', 1);
?>