<?php
if(!defined('IN_KKFRAME')) exit('Access Denied');

saveSetting('version', '1.13.9.8');
showmessage('成功更新到 1.13.9.8！', './', 1);
?>