/* Automatically generated file. Do not edit! */

#ifndef ECVERSION_H
#define ECVERSION_H

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifdef SVNDATE
#define EC_VERSION_ID "1196363addb4d95bc597f69aafb45ba7"
#endif

#endif /* ECVERSION_H */
