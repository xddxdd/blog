#ifndef ANTILEECH_AMULE_H
#define ANTILEECH_AMULE_H

/* Define DLPCheck prefs arg */
#define PF_MODSTRING	0x1
#define PF_USERHASH		0x2
#define PF_USERNAME		0x4
#define PF_HELLOTAG		0x8
#define PF_INFOTAG		0x10
#define PF_VERYCDEMULE	0x20
//#define PF_EASYMULE		0x40
//#define PF_MINIMULE	0x80
#define PF_GHOSTMOD	0x100

#endif
