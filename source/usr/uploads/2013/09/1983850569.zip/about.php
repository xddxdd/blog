<?php 
require_once ("Config.class.php");
require_once ("MySQLDAO.class.php");
session_start();
$username = $_SESSION['username'];
if(USERNAME != $username){
  	header("location:./login.php");
  	exit();
}
$yesterday = date('Ymd' , strtotime('yesterday'));
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>About</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.css">
    <!--[if lte IE 8]><link rel="stylesheet" href="css/responsive-nav.css"><![endif]-->
    <!--[if gt IE 8]><!--><link rel="stylesheet" href="css/styles.css"><!--<![endif]-->
	<script src="js/responsive-nav.js"></script>
  </head>
  <body>

    <div role="navigation" id="nav">
      <ul>
        <li><a href="./report.php">当日签到报告</a></li>
<?php 
echo "<li><a href=\"./report.php?date=".$yesterday."\">昨日签到报告</a></li>";
?>
		<li><a href="./history.php">历史签到报告</a></li>
        <li class="active"><a href="./about.php">关于</a></li>
        <li><a href="./logout.php">登出</a></li>
      </ul>
    </div>

    <div role="main" class="main">
      <a href="#nav" id="toggle">目录</a>
      <h1>About</h1>
      <p class="intro" style="font-weight: normal;">我有一只小公鸡呀我从来也不骑~~~</p>
      <p class="intro" style="font-weight: normal;">壮哉我大Chromer~~~</p>
    </div>

    <script>
      var navigation = responsiveNav("#nav", {customToggle: "#toggle"});
    </script>
  </body>
</html>

