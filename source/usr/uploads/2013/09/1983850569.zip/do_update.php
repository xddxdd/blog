<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
require_once ("SignTool.class.php");
$count = update_sign_list();
echo "更新签到列表完成，共获取".$count."个";
?>