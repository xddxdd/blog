<?php
//MySQL数据库名称,必须
define('DB_NAME' , '');
//消息队列名称，不需要发送消息则可不填
define('BCMS_QUEUE' , '');
//cookie，必须
define('COOKIE' , '');
//接收报告的Email
define('EMAIL' , '');
//简单登陆系统，用户名，必须
define('USERNAME' , '');
//简单登陆系统，密码，必须
define('PASSWORD' , '');
//消息报告总开关
define('SEND_MSG' , true);
//全部成功签到时发送报告
define('SEND_MSG_IF_ALL_SIGNED' , false);
//未全部签到时发送报告
define('SEND_MSG_IF_ANY_UNSIGNED_OR_SIGN_FAILED' , true);
//异常情况时发送报告(如:获取不到贴吧列表)
define('SEND_MSG_IF_MAY_HAS_SOMETHING_ERROR' , true);
?>