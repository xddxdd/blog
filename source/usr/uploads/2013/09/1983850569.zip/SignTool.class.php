<?php
require_once ("Config.class.php") ;
require_once ("BaeLog.class.php");
require_once ("MySQLDAO.class.php");
function delete($str) {
    $str = trim($str);
    $str = ereg_replace("\t","",$str);
    $str = ereg_replace("\r\n","",$str);
    $str = ereg_replace("\r","",$str);
    $str = ereg_replace("\n","",$str);
    $str = ereg_replace(" +","",$str);
    return trim($str);
}
function getmylike(){
	$pn = 0;
    $i = 0;
    $kw_name = '';
	while(true){
		$pn++;
		$mylikeurl="http://tieba.baidu.com/f/like/mylike?&pn=$pn";
		// echo $mylikeurl.'<br/>';
		$ch=curl_init($mylikeurl);
		curl_setopt($ch,CURLOPT_URL,$mylikeurl);
		curl_setopt($ch,CURLOPT_HEADER,0);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch,CURLOPT_COOKIE,COOKIE); 
		$result = curl_exec($ch);
		curl_close($ch);
		$result = delete($result);
		//echo $result."<br/>";
		$pre_reg = '/<tr><td>.*?<ahref="\/f\?kw=.*?"title="(.*?)"/';
		preg_match_all($pre_reg, $result, $matches);
		$count = 0;
		foreach ($matches[1] as $key => $value) {
			$value = urlencode(mb_convert_encoding($value, "utf-8", "gbk"));
			$kw_name .= $value.';';
			$i++;
			$count++;
		}
		if($count<=0){
			break;
		}
	}
  	if($i <= 0){
		return false;
	}
    return $kw_name;
}
function update_sign_list(){
	$kw_name = getmylike();
 	if(!$kw_name){
      	echo "获取失败";
      	return false;
  	}
  	$sign_date = date('Ymd');
  	$update_time = date("Y-m-d H:i:s");
  	$arr = explode(';', $kw_name);
	if (count($arr)>0){
		insert_history_item($sign_date,count($arr)-1,$update_time);
		foreach ($arr as $key => $value){
			if ($value == '')
				continue;
			insert_list_item($value,$sign_date);
		}
	}
  	return count($arr)-1;
}
function curl_get($url,$ua=false){
    $ch=curl_init($url);
    if ($ua){
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('User-Agent:Mozilla/5.0 (Linux; U; Android 2.3.4; zh-cn; W806 Build/GRJ22) AppleWebKit/530.17 (KHTML, like Gecko) FlyFlow/2.4 Version/4.0 Mobile Safari/530.17 baidubrowser/042_1.8.4.2_diordna_008_084/AIDIVN_01_4.3.2_608W/1000591a/9B673AC85965A58761CF435A48076629%7C880249110567268/1'));
    }
    else{
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('User-Agent:Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36','Connection:keep-alive','Referer:http://wapp.baidu.com/'));
    }
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch,CURLOPT_COOKIE,COOKIE); 
    $get_url = curl_exec($ch);
 	if($get_url !== false){
		$statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE); 
		if ($statusCode >= 500) { 
			return false;
		}
  	}
    curl_close($ch);
    return $get_url;
}
function do_sign($list_id,$tb_unicode_name){
	if (!isset($tb_unicode_name))
		continue;
	$url = "http://wapp.baidu.com/f?kw={$tb_unicode_name}";
	$get_url = curl_get($url);
  	if(!$get_url){
		echo urldecode($tb_unicode_name).'-服务器错误，签到失败，稍后会重试<br/>';
      	update_list_item($list_id,-1,0);
		return false;
	}
  	$get_url = delete($get_url);
  	preg_match_all('/<tdstyle="text-align:right;"><ahref="(.*?)">签到<\/a>/', $get_url, $matches);
	if (isset($matches[1][0])){
		$s = str_replace('&amp;', '&', $matches[1][0]);
		$sign_url = 'http://tieba.baidu.com'.$s;
		$get_sign = curl_get($sign_url,true);
     	if(!$get_sign){
          	echo urldecode($tb_unicode_name).'-签到时服务器错误，可能已成功，稍后会重试<br/>';
          	update_list_item($list_id,-1,0);
          	return false;
      	}
      	$get_sign = delete($get_sign);
      	preg_match_all('/<spanclass="light">签到成功，经验值上升<spanclass="light">(\d+)<\/span><br\/><\/span>/', $get_sign, $matches);
      	if (isset($matches[1][0])){
          	echo urldecode($tb_unicode_name)."-签到成功,经验值+".$matches[1][0]."<br/>";
          	update_list_item($list_id,1,$matches[1][0]);
          	return true;
        }else{
          	echo urldecode($tb_unicode_name)."-签到失败<br/>";
          	update_list_item($list_id,-1,0);
          	return true;
        }
	}else{
      	preg_match_all('/<tdstyle="text-align:right;"><span>已签到<\/span><\/td>/', $get_url, $matches);
      	if (isset($matches[0][0])){
          	echo urldecode($tb_unicode_name)."-此前已成功签到<br/>";
          	update_list_item($list_id,1,-1);
          	return false;
        }else{
          	echo urldecode($tb_unicode_name)."-不支持签到<br/>";
          	update_list_item($list_id,2,0);
          	return false;
        }
    }
}
function sign(){
  	$sign_date = date('Ymd');
	$tb_array = get_sign_item($sign_date);
  	$count = 0;
  	while($next =  each($tb_array)){
      	if($count>=3){
          	break;
      	}
      	$need_sleep = do_sign($next[key],$next[value]);
      	if($need_sleep){
          	$count++;
        	sleep(3);
      	}
  	}
}
?>