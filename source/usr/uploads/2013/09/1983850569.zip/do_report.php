<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
require_once ("ReportTool.class.php");
do_report();
?>