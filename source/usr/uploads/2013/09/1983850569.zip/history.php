<?php 
require_once ("Config.class.php");
require_once ("MySQLDAO.class.php");
session_start();
$username = $_SESSION['username'];
if(USERNAME != $username){
  	header("location:./login.php");
  	exit();
}
$yesterday = date('Ymd' , strtotime('yesterday'));
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>History</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.css">
    <!--[if lte IE 8]><link rel="stylesheet" href="css/responsive-nav.css"><![endif]-->
    <!--[if gt IE 8]><!--><link rel="stylesheet" href="css/styles.css"><!--<![endif]-->
	<script src="js/responsive-nav.js"></script>
  </head>
  <body>

    <div role="navigation" id="nav">
      <ul>
        <li><a href="./report.php">当日签到报告</a></li>
<?php 
echo "<li><a href=\"./report.php?date=".$yesterday."\">昨日签到报告</a></li>";
?>
		<li class="active"><a href="./history.php">历史签到报告</a></li>
        <li><a href="./about.php">关于</a></li>
        <li><a href="./logout.php">登出</a></li>
      </ul>
    </div>

    <div role="main" class="main">
      <a href="#nav" id="toggle">目录</a>
      <h1>History</h1>
      <p class="intro">目前仅列出最近30天的签到报告列表，若需查看其他日期的报告，可以：<br/>打开<a href="./report.php?date=yyyyMMdd" target="_blank">此链接</a>，然后将链接中的“yyyyMMdd”更改为需要查找的日期。<br/>如2013年1月1日则修改为“20130101”(不包含双引号)。</p>

	  <p>签到历史列表：</p>
		<table class="table table-hover">
        <thead>
          <tr>
            <th>#</th>
            <th>Date</th>
            <th>Total</th>
            <th>Failed</th>
            <th>UnSigned</th>
            <th>Succ</th>
            <th>UnSupp</th>
          </tr>
        </thead>
        <tbody>
<?php 
	$history_list = get_history_list();
	$i = 1;
	while($next =  each($history_list)){
      	$item = $next[value];
      	$tr = "<tr><td><a href=\"./report.php?date=".$item[history_date]."\" target=\"_blank\">".$i."</a></td>";
		$tr = $tr."<td><a href=\"./report.php?date=".$item[history_date]."\" target=\"_blank\">".$item[history_date]."</a></td>";
		$tr = $tr."<td><a href=\"./report.php?date=".$item[history_date]."\" target=\"_blank\">".$item[tb_num_all]."</a></td>";
		$tr = $tr."<td><a href=\"./report.php?date=".$item[history_date]."\" target=\"_blank\">".$item[tb_num_sign_failed]."</a></td>";
		$tr = $tr."<td><a href=\"./report.php?date=".$item[history_date]."\" target=\"_blank\">".$item[tb_num_unsigned]."</a></td>";
		$tr = $tr."<td><a href=\"./report.php?date=".$item[history_date]."\" target=\"_blank\">".$item[tb_num_signed]."</a></td>";
		$tr = $tr."<td><a href=\"./report.php?date=".$item[history_date]."\" target=\"_blank\">".$item[tb_num_sign_unsupped]."</a></td>";
      	$tr = $tr."</tr>";
      	echo $tr;
      	$i++;
  	}
?>
          <tr>
            <td>#</td>
            <td>Date</td>
            <td>Total</td>
            <td>Failed</td>
            <td>UnSigned</td>
            <td>Succ</td>
            <td>UnSupp</td>
            </tr>
        </tbody>
      </table>
    </div>

    <script>
      var navigation = responsiveNav("#nav", {customToggle: "#toggle"});
    </script>
  </body>
</html>

