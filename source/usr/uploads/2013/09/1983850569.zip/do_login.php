<?php
require_once ("Config.class.php");
session_start();
$username = $_POST["username"];
$password = $_POST["password"];
if(USERNAME == $username&&PASSWORD == $password){
  	$_SESSION['username'] = $username;
  	$_SESSION['error'] = "";
  	header("location:./report.php");
}else{
  	$_SESSION['error'] = "用户名或密码错误";
  	header("location:./login.php");
}

?>