<?php
require_once ("Bcms.class.php");
require_once ("BaeLog.class.php");
function send_mail($queueName,$subject,$message,$address ){
  	$logger=BaeLog::getInstance();
	$bcms = new Bcms();
  	$i = 1;
  	while(true){
    	$ret = $bcms->mail($queueName,$message,$address,array(Bcms::MAIL_SUBJECT => $subject));
		if (false === $ret){
          	if($i>5){
            	$logger ->logWarning("邮件发送失败");
      			return false;
          	}
      		$i++;
		}else{
			return true;
		}
  }
	
}

function send_sms( $queueName, $message, $address ){
  	//百度已将此服务关闭。
	global $accessKey, $secretKey, $host;
	$bcms = new Bcms();
	$ret = $bcms->sms ( $queueName, $message, $address ) ;
	if (false === $ret) {
		return false;
	}else{
		return true;
	}
}
?>
