<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
require_once ("SignTool.class.php");
sign();
echo "阶段性签到完成";
?>