<?php
require_once ("Config.class.php") ;
require_once ("BaeLog.class.php");
require_once ("MySQLDAO.class.php");
require_once ("Notification.class.php");
function do_report(){
  	$date = date("Ymd");
  	statistical_sign_status($date);
  	generate_and_send_report($date);
  	echo "done";
}
function statistical_sign_status($date){
  	$array = get_sign_status_count($date);
  	$tb_num_unsigned = 0;
  	$tb_num_signed = 0;
  	$tb_num_sign_failed = 0;
  	$tb_num_sign_unsupped = 0;
  	while($next =  each($array)){
      	$status = $next[key];
      	if($status == 1){
          	$tb_num_signed = $next[value];
      	}else if($status == 2){
          	$tb_num_sign_unsupped = $next[value];
      	}else if($status == -1){
          	$tb_num_sign_failed = $next[value];
      	}else if($status == 0){
          	$tb_num_unsigned = $next[value];
      	}
  	}
  	$sum = $tb_num_unsigned+$tb_num_signed+$tb_num_sign_failed+$tb_num_sign_unsupped;
  	update_history_item($date,$tb_num_unsigned,$tb_num_signed,$tb_num_sign_failed,$tb_num_sign_unsupped);
}
function generate_and_send_report($history_date){
  	if(!SEND_MSG)return true;
  	if (!ereg("^([a-zA-Z0-9_\-\.\+])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-])+",EMAIL))return false;
	$array = get_history_item($history_date);
  	if(empty($array)){
      	//可能有异常
      	if(SEND_MSG_IF_MAY_HAS_SOMETHING_ERROR){
          	$subject = date("Y年m月d日")."签到报告，完全失败了QAQ";
          	$msg = "\r\n".date("Y年m月d日")."签到报告\r\n";
          	$msg = $msg."今天没有获取到贴吧。。\r\n";
          	$msg = $msg."可能的原因有。。。\r\n";
          	$msg = $msg."Cookie失效了，快去重新设置~\r\n";
          	$msg = $msg."度娘改版了QAQ\r\n";
         	$msg = $msg."不对不对！我怎么可能会有问题，肯定是你打开的方式不对- -\r\n";
          	$msg = $msg."\r\nQAQ";
          	$res = send_mail(BCMS_QUEUE,$subject,$msg,array(EMAIL));
          	if($res){
              	echo "msg send success<br/>";
          	}
      	}
      	return true;
  	}
  	$tb_num_all = $array[tb_num_all];
    $tb_list_update_time = $array[tb_list_update_time];
    $tb_num_unsigned = $array[tb_num_unsigned];
    $tb_num_signed = $array[tb_num_signed];
    $tb_num_sign_failed = $array[tb_num_sign_failed];
    $tb_num_sign_unsupped = $array[tb_num_sign_unsupped];
  	if($tb_num_all==0){
      	//可能有异常
      	if(SEND_MSG_IF_MAY_HAS_SOMETHING_ERROR){
          	$subject = date("Y年m月d日")."签到报告，完全失败了QAQ";
          	$msg = "\r\n".date("Y年m月d日")."签到报告\r\n";
          	$msg = $msg."今天没有获取到贴吧。。\r\n";
          	$msg = $msg."可能的原因有。。。\r\n";
          	$msg = $msg."Cookie失效了，快去重新设置~\r\n";
          	$msg = $msg."度娘改版了QAQ\r\n";
         	$msg = $msg."不对不对！我怎么可能会有问题，肯定是你打开的方式不对- -\r\n";
          	$msg = $msg."\r\nQAQ";
          	$res = send_mail(BCMS_QUEUE,$subject,$msg,array(EMAIL));
          	$res = send_mail(BCMS_QUEUE,$subject,$msg,array(EMAIL));
          	if($res){
              	echo "msg send success<br/>";
          	}
      	}
      	return true;
  	}
  	if($tb_num_all == ($tb_num_signed+$tb_num_sign_unsupped)){
      	//全部签到成功
      	if(SEND_MSG_IF_ALL_SIGNED){
          	$subject = date("Y年m月d日")."签到报告，至少你让我签的我都签了~~";
          	$msg = "\r\n".date("Y年m月d日")."签到报告\r\n";
          	$msg = $msg."今天于".$tb_list_update_time."共获取到".$tb_num_all."个贴吧。\r\n";
          	$msg = $msg."其中：\r\n";
          	$msg = $msg."签到成功的贴吧共".$tb_num_signed."个\r\n";
          	$msg = $msg."不支持签到的贴吧共".$tb_num_sign_unsupped."个\r\n";
         	$msg = $msg."签到失败的贴吧共".$tb_num_sign_failed."个\r\n";
          	$msg = $msg."未执行签到的贴吧共".$tb_num_unsigned."个\r\n";
          	$msg = $msg."\r\n嘿嘿";
          	$res = send_mail(BCMS_QUEUE,$subject,$msg,array(EMAIL));
          	if($res){
              	echo "msg send success<br/>";
          	}
		}
      	return true;
  	}else{
      	if(SEND_MSG_IF_ANY_UNSIGNED_OR_SIGN_FAILED){
          	$subject = date("Y年m月d日")."签到报告，今天的签到貌似有点小问题...";
          	$msg = "\r\n".date("Y年m月d日")."签到报告\r\n";
          	$msg = $msg."今天于".$tb_list_update_time."共获取到".$tb_num_all."个贴吧。\r\n";
          	$msg = $msg."其中：\r\n";
          	$msg = $msg."签到成功的贴吧共".$tb_num_signed."个\r\n";
          	$msg = $msg."不支持签到的贴吧共".$tb_num_sign_unsupped."个\r\n";
         	$msg = $msg."签到失败的贴吧共".$tb_num_sign_failed."个\r\n";
          	$msg = $msg."未执行签到的贴吧共".$tb_num_unsigned."个\r\n";
          	$msg = $msg."\r\n未执行签到的贴吧:\r\n";
          	$tb_unsigned = get_list_item_by_status($history_date,0);
          	while($next =  each($tb_unsigned)){
              	$msg = $msg.$next[value]."吧\r\n";
            }
          	$msg = $msg."\r\n签到失败的贴吧:\r\n";
          	$tb_failed = get_list_item_by_status($history_date,-1);
          	while($next =  each($tb_failed)){
              	$msg = $msg.$next[value]."吧\r\n";
            }
          	$msg = $msg."\r\n无能为力了啊。。。快去帮我完成剩下的工作~";
          	$res = send_mail(BCMS_QUEUE,$subject,$msg,array(EMAIL));
          	if($res){
              	echo "msg send success<br/>";
          	}
        }
      	return true;
    }
}
?>