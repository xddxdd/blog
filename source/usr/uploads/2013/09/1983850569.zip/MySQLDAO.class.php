<?php
require_once ("Config.class.php") ;
require_once ("BaeLog.class.php");
require_once ("MySQLConnecter.class.php");
function insert_list_item($tb_unicode_name,$date){
	$conn = getConn();
	if(!$conn){
		echo "数据库连接失败".mysqli_connect_error();
		exit();
	}
	$sql = "insert into tb_sign_list(tb_name,tb_unicode_name,sign_date)values(?,?,?)";
	$result=$conn->prepare($sql);
	if($result){
		$result->bind_param("sss",urldecode($tb_unicode_name),$tb_unicode_name,$date);
		$result->execute();
		$result->close();
	}
}

function insert_history_item($history_date,$tb_num_all,$update_time){
	$conn = getConn();
	if(!$conn){
		echo "数据库连接失败".mysqli_connect_error();
		exit();
	}
	$sign_date = date('Ymd');
 	$sql = "INSERT INTO tb_sign_history(history_date, tb_num_all, tb_list_update_time) VALUES (?,?,?)";
	$result=$conn->prepare($sql);
	if($result){
		$result->bind_param("sis",$history_date,$tb_num_all,$update_time);
		$result->execute();
		$result->close();
	}
}

function update_list_item($list_id,$sign_status,$sign_exp){
	$conn = getConn();
	if(!$conn){
		echo "数据库连接失败".mysqli_connect_error();
		exit();
	}
	$sql = "UPDATE tb_sign_list SET sign_status=?,sign_exp=? WHERE list_id = ?";
	$result=$conn->prepare($sql);
	if($result){
		$result->bind_param("iii",$sign_status,$sign_exp,$list_id);
		$result->execute();
		$result->close();
	}
}

function update_history_item($history_date,$tb_num_unsigned,$tb_num_signed,$tb_num_sign_failed,$tb_num_sign_unsupped){
	$conn = getConn();
	if(!$conn){
		echo "数据库连接失败".mysqli_connect_error();
		exit();
	}
	$sql = "UPDATE tb_sign_history SET tb_num_unsigned=?,tb_num_signed=?,tb_num_sign_failed=?,tb_num_sign_unsupped=? WHERE history_date=?";
	$result=$conn->prepare($sql);
	if($result){
		$result->bind_param("iiiis",$tb_num_unsigned,$tb_num_signed,$tb_num_sign_failed,$tb_num_sign_unsupped,$history_date);
		$result->execute();
		$result->close();
	}
}

function get_sign_item($sign_date){
	$conn = getConn();
	if(!$conn){
		echo "数据库连接失败".mysqli_connect_error();
		exit();
	}
	$tb_array = array();
	$sql = "SELECT list_id,tb_unicode_name FROM tb_sign_list WHERE sign_status<=0 AND sign_date = ? order by sign_status desc,list_id asc limit 0,20";
	$result=$conn->prepare($sql);
	if($result){
		$result->bind_param("s",$sign_date);
		$result->execute();
		$result->bind_result($list_id,$tb_unicode_name);
		while ($result->fetch()) {
			$tb_array[$list_id] = $tb_unicode_name;
		}
		$result->close();
	}
	return $tb_array;
}

function get_list_item_by_status($sign_date,$sign_status,$unicode=false){
	$conn = getConn();
	if(!$conn){
		echo "数据库连接失败".mysqli_connect_error();
		exit();
	}
	$tb_array = array();
	$sql = "SELECT list_id,tb_name FROM tb_sign_list WHERE sign_status=? and sign_date=?";
	if($unicode){
		$sql = "SELECT list_id,tb_unicode_name FROM tb_sign_list WHERE sign_status=? and sign_date=?";
	}
	$result=$conn->prepare($sql);
	if($result){
		$result->bind_param("is",$sign_status,$sign_date);
		$result->execute();
		$result->bind_result($list_id,$tb_name);
		while ($result->fetch()) {
			$tb_array[$list_id] = $tb_name;
		}
		$result->close();
	}
	return $tb_array;
}

function get_failed_list_item_by_date($sign_date){
	$conn = getConn();
	if(!$conn){
		echo "数据库连接失败".mysqli_connect_error();
		exit();
	}
	$tb_array = array();
	$sql = "SELECT list_id,tb_name,sign_status,sign_exp FROM tb_sign_list WHERE sign_status<=0 and sign_date=? ORDER BY sign_status DESC,list_id ASC";
	$result=$conn->prepare($sql);
	if($result){
		$result->bind_param("s",$sign_date);
		$result->execute();
		$result->bind_result($list_id,$tb_name,$sign_status,$sign_exp);
		while ($result->fetch()) {
          	$tb = array();
          	$tb[tb_name] = $tb_name;
          	$tb[sign_status] = $sign_status;
          	$tb[sign_exp] = $sign_exp;
			$tb_array[$list_id] = $tb;
		}
		$result->close();
	}
	return $tb_array;
}

function get_success_list_item_by_date($sign_date){
	$conn = getConn();
	if(!$conn){
		echo "数据库连接失败".mysqli_connect_error();
		exit();
	}
	$tb_array = array();
	$sql = "SELECT list_id,tb_name,sign_status,sign_exp FROM tb_sign_list WHERE sign_status>0 and sign_date=? ORDER BY sign_status ASC,list_id ASC";
	$result=$conn->prepare($sql);
	if($result){
		$result->bind_param("s",$sign_date);
		$result->execute();
		$result->bind_result($list_id,$tb_name,$sign_status,$sign_exp);
		while ($result->fetch()) {
          	$tb = array();
          	$tb[tb_name] = $tb_name;
          	$tb[sign_status] = $sign_status;
          	$tb[sign_exp] = $sign_exp;
			$tb_array[$list_id] = $tb;
		}
		$result->close();
	}
	return $tb_array;
}

function get_history_list(){
	$conn = getConn();
	if(!$conn){
		echo "数据库连接失败".mysqli_connect_error();
		exit();
	}
	$his_array = array();
	$sql = "SELECT history_id, history_date, tb_num_all, tb_num_unsigned, tb_num_signed, tb_num_sign_failed, tb_num_sign_unsupped FROM tb_sign_history ORDER BY history_date desc LIMIT 0, 30 ";
	$result=$conn->prepare($sql);
	if($result){
		$result->execute();
		$result->bind_result($history_id, $history_date, $tb_num_all, $tb_num_unsigned, $tb_num_signed, $tb_num_sign_failed, $tb_num_sign_unsupped);
		while ($result->fetch()) {
          	$his = array();
          	$his[history_id] = $history_id;
          	$his[history_date] = $history_date;
          	$his[tb_num_all] = $tb_num_all;
          	$his[tb_num_unsigned] = $tb_num_unsigned;
          	$his[tb_num_signed] = $tb_num_signed;
          	$his[tb_num_sign_failed] = $tb_num_sign_failed;
          	$his[tb_num_sign_unsupped] = $tb_num_sign_unsupped;
			$his_array[$history_id] = $his;
		}
		$result->close();
	}
	return $his_array;
}

function get_history_item($history_date){
	$conn = getConn();
	if(!$conn){
		echo "数据库连接失败".mysqli_connect_error();
		exit();
	}
	$array = array();
	$sql = "SELECT tb_num_all,tb_list_update_time,tb_num_unsigned,tb_num_signed,tb_num_sign_failed,tb_num_sign_unsupped FROM tb_sign_history WHERE history_date=? LIMIT 1";
	$result=$conn->prepare($sql);
	if($result){
		$result->bind_param("s",$history_date);
		$result->execute();
		$result->bind_result($tb_num_all,$tb_list_update_time,$tb_num_unsigned,$tb_num_signed,$tb_num_sign_failed,$tb_num_sign_unsupped);
		while ($result->fetch()) {
			$array[tb_num_all] = $tb_num_all;
			$array[tb_list_update_time] = $tb_list_update_time;
			$array[tb_num_unsigned] = $tb_num_unsigned;
			$array[tb_num_signed] = $tb_num_signed;
			$array[tb_num_sign_failed] = $tb_num_sign_failed;
			$array[tb_num_sign_unsupped] = $tb_num_sign_unsupped;
			break;
		}
		$result->close();
	}
	return $array;
}

function get_sign_status_count($sign_date){
	$conn = getConn();
	if(!$conn){
		echo "数据库连接失败".mysqli_connect_error();
		exit();
	}
	$tb_array = array();
	$sql = "SELECT sign_status,COUNT(list_id) as num FROM tb_sign_list WHERE sign_date=? GROUP BY sign_status";
	$result=$conn->prepare($sql);
	if($result){
		$result->bind_param("s",$sign_date);
		$result->execute();
		$result->bind_result($sign_status,$num);
		while ($result->fetch()) {
			$tb_array[$sign_status] = $num;
		}
		$result->close();
	}
	return $tb_array;
}
?>