<?php
require_once ("Config.class.php") ;
require_once ("BaeLog.class.php");
function getConn(){
  $logger=BaeLog::getInstance();
  $host = getenv('HTTP_BAE_ENV_ADDR_SQL_IP');
  $port = getenv('HTTP_BAE_ENV_ADDR_SQL_PORT');
  $user = getenv('HTTP_BAE_ENV_AK');
  $pwd = getenv('HTTP_BAE_ENV_SK');
  $conn = @new mysqli($host, $user, $pwd, DB_NAME, $port);
  if(!$conn) {
	$logger ->logFatal("Connect Server Failed:".$conn->connect_error);
    return false;
  }else{
 	 return $conn;
  }
}
?>