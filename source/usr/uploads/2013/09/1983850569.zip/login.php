<?php 
require_once ("Config.class.php");
session_start();
$username = $_SESSION['username'];
if(USERNAME == $username){
  	header("location:./report.php");
  	exit();
}
?>
<!DOCTYPE html>
<html><head>
    <meta charset="utf-8">
    <title>Login in</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Le styles -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <style type="text/css">
      body {
        padding-top: 120px;
        padding-bottom: 40px;
		text-shadow: 0 1px 3px rgba(0,0,0,.4), 0 0 30px rgba(0,0,0,.075);
		background: #ECF0F1 url("img/debut_dark.png") repeat;
		color: #666;
		font: normal 100%/1.5 "微软雅黑","Microsoft Yahei Mono", "Microsoft Yahei","Helvetica Neue", Helvetica, Arial, sans-serif;
      }

      .form-signin {
        max-width: 300px;
        padding: 19px 29px 29px;
        margin: 0 auto 20px;
        background-color: #fff;
        border: 1px solid #e5e5e5;
        -webkit-border-radius: 5px;
           -moz-border-radius: 5px;
                border-radius: 5px;
        -webkit-box-shadow: 0 1px 2px rgba(0,0,0,.05);
           -moz-box-shadow: 0 1px 2px rgba(0,0,0,.05);
                box-shadow: 0 1px 2px rgba(0,0,0,.05);
      }
      .form-signin .form-signin-heading,
      .form-signin .checkbox {
        margin-bottom: 10px;
      }
      .form-signin input[type="text"],
      .form-signin input[type="password"] {
        font-size: 16px;
        height: auto;
        margin-bottom: 15px;
        padding: 7px 9px;
      }
	@media screen and (-webkit-min-device-pixel-ratio: 1.3), screen and (min--moz-device-pixel-ratio: 1.3), screen and (-o-min-device-pixel-ratio: 2 / 1), screen and (min-device-pixel-ratio: 1.3), screen and (min-resolution: 192dpi), screen and (min-resolution: 2dppx) {
		body {
			background-image: url("img/debut_dark_@2X.png");
			-webkit-background-size: 200px 200px;
			-moz-background-size: 200px 200px;
			-o-background-size: 200px 200px;
			background-size: 200px 200px;
		}
	}
}
    </style>
  <body>

    <div class="container">

      <form class="form-signin" action="./do_login.php" method="post">
        <h2 class="form-signin-heading">Please login in</h2>
        <input type="text" name="username" class="input-block-level" placeholder="Username">
        <input type="password" name="password" class="input-block-level" placeholder="Password">
        <label>
        <?php echo $_SESSION['error'];unset($_SESSION['error']);?>
        </label>
        <button class="btn btn-large btn-inverse" type="submit">Login in</button>
      </form>

    </div> <!-- /container -->
</body>
</html>
