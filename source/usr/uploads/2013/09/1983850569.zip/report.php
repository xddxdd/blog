<?php 
require_once ("Config.class.php");
require_once ("MySQLDAO.class.php");
session_start();
$username = $_SESSION['username'];
if(USERNAME != $username){
  	header("location:./login.php");
  	exit();
}
$yesterday = date('Ymd' , strtotime('yesterday'));
$date = $_GET['date'];
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Report</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.css">
    <!--[if lte IE 8]><link rel="stylesheet" href="css/responsive-nav.css"><![endif]-->
    <!--[if gt IE 8]><!--><link rel="stylesheet" href="css/styles.css"><!--<![endif]-->
	<script src="js/responsive-nav.js"></script>
  </head>
  <body>

    <div role="navigation" id="nav">
      <ul>
<?php 
echo "<li";
if(!$date){
  echo " class=\"active\"";
}
echo "><a href=\"./report.php\">当日签到报告</a></li>";
echo "<li";
if($date==$yesterday){
  echo " class=\"active\"";
}
echo "><a href=\"./report.php?date=".$yesterday."\">昨日签到报告</a></li>";
echo "<li";
if($date&&$date<$yesterday){
  echo " class=\"active\"";
}
echo "><a href=\"./history.php\">历史签到报告</a></li>";
?>

        <li><a href="./about.php">关于</a></li>
        <li><a href="./logout.php">登出</a></li>
      </ul>
    </div>

    <div role="main" class="main">
      <a href="#nav" id="toggle">目录</a>
      <h1>Report</h1>
      <p class="intro">
<?php 

$intro = "";
if(ereg("[0-9]{8}",$date)){
  	$tmp = substr($date,0,4)."年".substr($date,4,2)."月".substr($date,6,2)."日";
	$intro = $intro.$tmp;
  	
}else{
  	$intro = $intro.date("Y年m月d日")."(今天)";
  	$date = date("Ymd");
}
$intro = $intro."的签到报告，当天共获取到";
$history_item = get_history_item($date);
$intro = $intro.$history_item[tb_num_all]."个喜欢的贴吧(于".$history_item[tb_list_update_time].")。<br/>其中：<br/>签到成功的贴吧数为".$history_item[tb_num_signed]."个，不支持签到的贴吧数为".$history_item[tb_num_sign_unsupped]."个；<br/>签到失败的贴吧数为".$history_item[tb_num_sign_failed]."个，未执行签到的贴吧数为".$history_item[tb_num_unsigned]."个。";
echo $intro;
?>
      </p>
		<p>签到失败及未执行签到的贴吧：</p>
		<table class="table table-hover">
        <thead>
          <tr>
            <th>#</th>
            <th>TieBa</th>
            <th>Status</th>
			<th>Exp</th>
          </tr>
        </thead>
        <tbody>
<?php 
	$failed = get_failed_list_item_by_date($date);
	$i = 1;
	while($next =  each($failed)){
      	$item = $next[value];
      	$tr = "<tr><td>".$i."</td><td>".$item[tb_name]."</td><td>";
      	switch ($item[sign_status]){
			case -1:$tr = $tr."失败";break;
          	case 0:$tr = $tr."未执行";break;
          	case 1:$tr = $tr."成功";break;
          	case 2:$tr = $tr."不支持";break;
		}
      	$tr = $tr."</td><td>";
      	if($item[sign_exp]<0){
          	$tr = $tr."未知";
      	}else{
          	$tr = $tr.$item[sign_exp];
        }
      	$tr = $tr."</td></tr>";
      	echo $tr;
      	$i++;
  	}
?>
        </tbody>
      </table>
	  <p>签到成功及不支持签到的贴吧：</p>
		<table class="table table-hover">
        <thead>
          <tr>
            <th>#</th>
            <th>TieBa</th>
            <th>Status</th>
			<th>Exp</th>
          </tr>
        </thead>
        <tbody>
<?php 
	$failed = get_success_list_item_by_date($date);
	$i = 1;
	while($next =  each($failed)){
      	$item = $next[value];
      	$tr = "<tr><td>".$i."</td><td>".$item[tb_name]."</td><td>";
      	switch ($item[sign_status]){
			case -1:$tr = $tr."失败";break;
          	case 0:$tr = $tr."未执行";break;
          	case 1:$tr = $tr."成功";break;
          	case 2:$tr = $tr."不支持";break;
		}
      	$tr = $tr."</td><td>";
      	if($item[sign_exp]<0){
          	$tr = $tr."未知";
      	}else{
          	$tr = $tr.$item[sign_exp];
        }
      	$tr = $tr."</td></tr>";
      	echo $tr;
      	$i++;
  	}
?>
        </tbody>
      </table>
    </div>

    <script>
      var navigation = responsiveNav("#nav", {customToggle: "#toggle"});
    </script>
  </body>
</html>

